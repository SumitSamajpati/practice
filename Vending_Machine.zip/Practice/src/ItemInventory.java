import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ItemInventory<T> {

	private Map<String,ArrayList<Integer>> inventory=new HashMap<String,ArrayList<Integer>>();
	//private Map<Item,Integer> inboundItem = new HashMap<Item,Integer>()
	//ArrayList -- 1st index for current quantity, 2nd for price, 3rd for inbound quantity
		
	public int getQuantity(Item item){		
		ArrayList<Integer> itemData = inventory.get(item.getName());
		return itemData== null?0:itemData.get(0);
	}
	public int getInboundQuantity(Item item){		
		ArrayList<Integer> itemData = inventory.get(item.getName());
		Integer value = itemData.get(2);
		return value== null?0:value;
	}
	
	public void add(Item item, int quanity){
		int currentCount,inboundCount,price;
		ArrayList<Integer> itemData=new ArrayList<Integer>();
		if(hasItem(item.getName())){
			itemData = inventory.get(item.getName());
			currentCount = itemData.get(0);
			price= item.getPrice();
			inboundCount = itemData.get(2);
		}
		else{ 
			currentCount= 0;
			price= item.getPrice();
			inboundCount=0;
		}
		
		if(itemData.size()==0){
			itemData.add(0, currentCount+quanity);
			itemData.add(1, price);
			itemData.add(2, inboundCount+quanity);
		}else{
			itemData.set(0,currentCount+quanity);
			itemData.set(1,price);
			itemData.set(2, inboundCount+quanity);
		}
		
		inventory.put(item.getName(),itemData);
	}
	
	public void deduct(Item item, int quantity){
		if(hasItem(item.getName())){
			int count;
			ArrayList<Integer> itemData=new ArrayList<>();
			itemData = inventory.get(item.getName());
					
			count= itemData.get(0);
			
			if(itemData.size() == 0)
				itemData.add(0,count-quantity);
			else
				itemData.set(0,count-quantity);
			
			inventory.put(item.getName(),itemData);
		}
	}	
	
	public void remove(Item item){
		if(hasItem(item.getName())){
			inventory.remove(item);
		}
	}
	
	public Map<String,ArrayList<Integer>> availableInventory(){
		return inventory;
	}
	
	public boolean hasItem(String item){
		
		 return inventory.containsKey(item);
	}
	public void clear(){
		inventory.clear();
	}
	
	public ArrayList<Integer> getItemData(String name){
		if(hasItem(name))
			return inventory.get(name);
		else
		    return null;
	}		
}
