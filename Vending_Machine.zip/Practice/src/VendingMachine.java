
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* Public API for Vending Machine*/
public interface VendingMachine{
	//public void initialize();
	public Item getItem(String name);
	public void loadItems(String name,  int price, int amount);
	public void loadItems(String name, int quantity);
	public int GetPrice(String name, int quantity);
	//public int selectItemAndGetPrice(Item item);
	public void insertcoin(Coin coin, int qunatity);
	public void avilableItems();
	public void addCash(int input_amount);
	public void reduceQuantity(String name, int quantity);
	public Map<Coin,Integer> refund();
	public Bucket<Item, Map<Coin, Integer>> collectItemAndChange(Item item, int quantity, int amount);
	public Map<String,ArrayList<Integer>> getItemInventoryInstance();
	public void updateItemPrice(String name, int price);
	public int getTotalSales();
	public void getSoldItemList();
	public void printInventory();
	public void resetInventory();
	public void resetItemInventory();
	public void resetCashInventory();
	public void exitVendingMachine();
}
