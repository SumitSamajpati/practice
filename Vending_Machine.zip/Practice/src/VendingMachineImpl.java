import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public  class VendingMachineImpl implements VendingMachine {
		private CoinInventory<Coin> cashInventory= new CoinInventory<Coin>();
		private ItemInventory<Item> itemInventory= new ItemInventory<Item>();
		//ArrayList for further metadata of inbound items in future. Key is name of the item, values are metadata (price, quantity as of now)
				
		public static int totalSales, refundAmount;
		private int totalPrice, reducedQuantity;
			
		public VendingMachineImpl() {
			
			initialize();
		}
		
		private void initialize(){
			for(Coin c:Coin.values()){
				cashInventory.add(c,10);
			}
		}
	
	public void loadItems(String name,  int price, int quantity) {
		
		Item item= getItem(name);
		if (itemInventory.hasItem(name)) {
			 
			int currentQuantity= itemInventory.getQuantity(item);
			int existingPrice = item.getPrice();
			
			if(existingPrice == price){
				loadItems(name, quantity);
				return;
			}
			
			item.setPrice(price);
			itemInventory.add(item,currentQuantity+quantity); 
			avilableItems();		
		}
		else { 		
		
				item = new Item(name, price);
				 				
				itemInventory.add(item,quantity);
				avilableItems();
			}
	}
	
	
public void loadItems(String name, int quantity) {
			Item item= getItem(name);
		 	int currentQuantity= itemInventory.getQuantity(item);
				
			itemInventory.add(item,currentQuantity+quantity); 
			//System.out.println(itemInventory.availableInventory());
			avilableItems();
}
	
	public Item getItem(String name){
	
		if(itemInventory.hasItem(name)) {
		    	ArrayList<Integer> itemMetadata =itemInventory.getItemData(name);
		    	int price = itemMetadata.get(1);
		    		    	
		    	return new Item(name,price);
		}
		else
		 return new Item(name,0);
		
		
}
	
	public int GetPrice(String name, int quantity){
		Item item= getItem(name);
		int itemPrice= item.getPrice();
		totalPrice=itemPrice*quantity;
		return totalPrice;
	}
	
	
/*	public int selectItemAndGetPrice(Item item) {
	    if(itemInventory.hasItem(item.getName())){
	      currentItem=item;	
	    return currentItem.getPrice();	
	    	
	    }
		throw new SoldOutException("Sold out, please buy another item");
	}*/

	public void addCash(int amount){
		
		int two_thousand = amount / 2000;
		amount=amount%2000;
		int five_hundred = amount / 500;
		amount=amount%500;
		int hundred = amount / 100;
		amount=amount%100;
		int fifty = amount / 50;
		amount=amount%50;
		int twenty = amount / 20;
		amount=amount%20;
		int ten = amount / 10;
		amount=amount%10;
		int five = amount / 5;
		amount=amount%5;
		int two = amount / 2;
		amount=amount%2;
		int one = amount/1;
		
		if(two_thousand != 0)
			insertcoin(Coin.TWO_THOUSAND, two_thousand);
		if(five_hundred != 0)
			insertcoin(Coin.FIVE_HUNDRED, five_hundred);
		if(hundred != 0)
			insertcoin(Coin.HUNDRED, hundred);
		if(fifty != 0)
			insertcoin(Coin.FIFTY, fifty);
		if(twenty != 0)
			insertcoin(Coin.TWENTY, twenty);
		if(ten != 0)
			insertcoin(Coin.TEN, ten);
		if(five != 0)
			insertcoin(Coin.FIVE, five);
		if(two != 0)
			insertcoin(Coin.TWO, two);
		if(one != 0)
			insertcoin(Coin.ONE, one);
		
        
	}
	

	public void insertcoin(Coin coin, int qunatity) {
		//currentBalance = currentBalance + coin.getDenomination();
         cashInventory.add(coin, qunatity);
	}

	
	public Bucket<Item, Map<Coin, Integer>> collectItemAndChange(Item currentItem, int quantity, int amount) {
	//	totalPrice=currentItem.getPrice() * quantity;
		Item item = collectItem(currentItem,quantity, amount);
		totalPrice= currentItem.getPrice()*quantity;
		Map<Coin,Integer> change= collectChange(amount-totalPrice);
		totalSales+=totalPrice;
		refundAmount=amount;
		return new Bucket<Item, Map<Coin,Integer>>(item, change);
		
	}

	public Item collectItem(Item currentItem, int quantity, int amount) throws NotSufficientChangeException,NotFullPaidException, SoldOutException{
		if(quantity<itemInventory.getQuantity(currentItem)){
		if(isFullPaid(currentItem,quantity, amount)){
		if(hasSufficientChange(currentItem, quantity, amount)){
			itemInventory.deduct(currentItem, quantity); 
			return currentItem; 
		} 
		throw new NotSufficientChangeException("Not Sufficient change in Inventory"); 
		} 
		int remainingBalance = amount- currentItem.getPrice()*quantity; 
		System.out.println("Price not full paid, remaining :"+remainingBalance);		
		throw new NotFullPaidException("Price not full paid, remaining : ", remainingBalance);			
		}
		System.out.println("Not sufficient number of items in the inventory");
		throw new SoldOutException("Not sufficient number of items in the inventory");
	}

	private boolean isFullPaid(Item currentItem, int quantity, int amount) { 
		if(amount >= currentItem.getPrice()*quantity){
			return true; 
		} 
	 return false;
    }

	private boolean hasSufficientChange(Item item, int quantity, int amount){ 
		return hasSufficientChangeForAmount(amount - item.getPrice()*quantity);
	}
	
	private boolean hasSufficientChangeForAmount(int changeAmount){ 
		boolean hasChange = true; 
		try{ 
			getChange(changeAmount); 
		}catch(NotSufficientChangeException nsce){ 
			return hasChange = false; 
		} 
		return hasChange; 
	}
	
	private Map<Coin,Integer> collectChange(int changeAmount) {
		
		Map<Coin,Integer> change = getChange(changeAmount);
		updateCashInventory(change); 
		return change; 
	}

	public Map<Coin,Integer> getChange(long amount) throws NotSufficientChangeException{
		Map<Coin,Integer> coinMap = new HashMap<Coin,Integer>();
		long balance = amount;
		while (balance > 0) {
			if (balance >= Coin.TWO_THOUSAND.getDenomination() && cashInventory.hasItem(Coin.TWO_THOUSAND) && cashInventory.getQuantity(Coin.TWO_THOUSAND) >= balance/Coin.TWO_THOUSAND.getDenomination()) {
				coinMap.put(Coin.TWO_THOUSAND,coinMap.get(Coin.TWO_THOUSAND) == null ? 1 : coinMap.get(Coin.TWO_THOUSAND)+1);
				balance-=Coin.TWO_THOUSAND.getDenomination();
				continue;
			} else if (balance >= Coin.FIVE_HUNDRED.getDenomination() && cashInventory.hasItem(Coin.FIVE_HUNDRED) && cashInventory.getQuantity(Coin.FIVE_HUNDRED) >= balance/Coin.FIVE_HUNDRED.getDenomination()) {
				coinMap.put(Coin.FIVE_HUNDRED,coinMap.get(Coin.FIVE_HUNDRED) == null ? 1 : coinMap.get(Coin.FIVE_HUNDRED)+1);
				balance-=Coin.FIVE_HUNDRED.getDenomination();
				continue;
			} else if (balance >= Coin.HUNDRED.getDenomination() && cashInventory.hasItem(Coin.HUNDRED) && cashInventory.getQuantity(Coin.HUNDRED) >= balance/Coin.HUNDRED.getDenomination()) {
				coinMap.put(Coin.HUNDRED,coinMap.get(Coin.HUNDRED) == null ? 1 : coinMap.get(Coin.HUNDRED)+1);
				balance-=Coin.HUNDRED.getDenomination();
				continue;
			} else if (balance >= Coin.FIFTY.getDenomination() && cashInventory.hasItem(Coin.FIFTY) && cashInventory.getQuantity(Coin.FIFTY) >= balance/Coin.FIFTY.getDenomination()) {
				coinMap.put(Coin.FIFTY,coinMap.get(Coin.FIFTY) == null ? 1 : coinMap.get(Coin.FIFTY)+1);
				balance-=Coin.FIFTY.getDenomination();
				continue;
			} else if (balance >= Coin.TWENTY.getDenomination() && cashInventory.hasItem(Coin.TWENTY) && cashInventory.getQuantity(Coin.TWENTY) >= balance/Coin.TWENTY.getDenomination()) {
				coinMap.put(Coin.TWENTY,coinMap.get(Coin.TWENTY) == null ? 1 : coinMap.get(Coin.TWENTY)+1);
				balance-=Coin.TWENTY.getDenomination();
				continue;
			} else if (balance >= Coin.TEN.getDenomination() && cashInventory.hasItem(Coin.TEN) && cashInventory.getQuantity(Coin.TEN) >= balance/Coin.TEN.getDenomination()) {
				coinMap.put(Coin.TEN,coinMap.get(Coin.TEN) == null ? 1 : coinMap.get(Coin.TEN)+1);
				balance-=Coin.TEN.getDenomination();
				continue;
			} else if (balance >= Coin.FIVE.getDenomination() && cashInventory.hasItem(Coin.FIVE) && cashInventory.getQuantity(Coin.FIVE) >= balance/Coin.FIVE.getDenomination()) {
				coinMap.put(Coin.FIVE,coinMap.get(Coin.FIVE) == null ? 1 : coinMap.get(Coin.FIVE)+1);
				balance-=Coin.FIVE.getDenomination();
				continue;
			} else if (balance >= Coin.TWO.getDenomination() && cashInventory.hasItem(Coin.TWO) && cashInventory.getQuantity(Coin.TWO) >= balance/Coin.TWO.getDenomination()) {
				coinMap.put(Coin.TWO,coinMap.get(Coin.TWO) == null ? 1 : coinMap.get(Coin.TWO)+1);
				balance-=Coin.TWO.getDenomination();
				continue;
			} else if (balance >= Coin.ONE.getDenomination() && cashInventory.hasItem(Coin.ONE) && cashInventory.getQuantity(Coin.ONE) >= balance/Coin.ONE.getDenomination()) {
				coinMap.put(Coin.ONE,coinMap.get(Coin.ONE) == null ? 1 : coinMap.get(Coin.ONE)+1);
				balance-=Coin.ONE.getDenomination();
				continue;
			} else {
				throw new NotSufficientChangeException("Not sufficient Change Exception, please try another product");
			}
		}
		return coinMap;
	}

	private void updateCashInventory(Map<Coin,Integer> change) { 
		
		for (Map.Entry<Coin, Integer> entry : change.entrySet()) {
		    
			cashInventory.deduct(entry.getKey(),entry.getValue());
		}
	}

	public void updateItemPrice(String name, int price) { 
		Item item= getItem(name);
		
		if (itemInventory.hasItem(name)) {
			int quantity= itemInventory.getQuantity(item);
			item.setPrice(price);
			itemInventory.add(item,quantity);
			System.out.println("Revised price of"+ name + " is set to Rs" + price);
			avilableItems();
		}
		else
			System.out.println("Item is out of stock !");
	}
	public int getTotalSales(){ 
		return totalSales;
	}
	
	public void getSoldItemList(){
		  //intermediate price changes in total sales calculation not considered
		int token=0;
		System.out.println("\n item" + " \t\t"+ "Price"+  "\t\t"+ "Sold Quantity");
		System.out.println("-----------------------------------------------------");
		for (String key : itemInventory.availableInventory().keySet()) {
			
			/*Item item= vmImpl.getItem(key);
			ArrayList<String> arr= new ArrayList<>();
			int inboundQuantity = arr.lastIndexOf(inboundItem.get(key));
			
			int currentQuantity = itemInventory.getQuantity(item);*/
			
			int inboundQuantity = itemInventory.getInboundQuantity(getItem(key));
			int currentQuantity = itemInventory.getQuantity(getItem(key));
			
			if(inboundQuantity-reducedQuantity-currentQuantity>0){		
				System.out.println("\n"+ key + " \t\t" + getItem(key).getPrice() +" \t\t"+ (inboundQuantity -reducedQuantity- currentQuantity));
				token++;
			}
		}
		if(token == 0)
			System.out.println(" No item sold yet !");
	}
	public void reduceQuantity(String name, int quantity){
		Item item=getItem(name);
		itemInventory.deduct(item, quantity);
		reducedQuantity=quantity;
		avilableItems();
	}

	public void avilableItems(){
		
	 	System.out.println("Item Name"+"\t"+"Price"+"\t"+"Quantity");
	 	System.out.println("---------------------------------------");
		
	    Map<String,ArrayList<Integer>> availableItem = itemInventory.availableInventory();
	    
	    for (Map.Entry<String, ArrayList<Integer>> entry : availableItem.entrySet())
	    {
	        System.out.println(entry.getKey() + "\t" +entry.getValue().get(1)+"\t" + entry.getValue().get(0));
	    }		
	}
	
	
	public Map<Coin,Integer> refund(){
		Map<Coin,Integer> refund = getChange(refundAmount); 
		updateCashInventory(refund); 
		
		return refund;
	}

	
	public void resetInventory(){ 
		
		resetItemInventory();
		resetCashInventory();
		printInventory();
	} 
	
	public void resetItemInventory(){
		itemInventory.clear(); 
		totalSales = 0; 
		refundAmount=0;
		System.out.println("Item inventory has been reset !");
		printInventory();
	}
		
	public void resetCashInventory(){
		cashInventory.clear();
		initialize();		
		totalSales = 0; 
		refundAmount=0;
		System.out.println("Cash inventory has been reset !");
		printInventory();
	}
	public void printInventory(){ 
		Map<String,ArrayList<Integer>> itemInventoryObj=itemInventory.availableInventory();
		if(itemInventoryObj.isEmpty())
			System.out.println("Item inventory is empty !");
		else
			System.out.println("Current Item Inventory : " + itemInventory.availableInventory()); 
		
		Map<Coin, Integer> coinInventoryObj = cashInventory.availableInventory();
		if(coinInventoryObj.isEmpty())
			System.out.println("Cash inventory is empty !");
		else
			System.out.println("Current Cash Inventory : " + cashInventory.availableInventory());
	} 

	public Map<String,ArrayList<Integer>> getItemInventoryInstance(){
		Map<String,ArrayList<Integer>> itemInventoryObj=itemInventory.availableInventory();
		return itemInventoryObj;
	}
	
	public Map<Coin, Integer> getCashInventoryInstance(){
		Map<Coin, Integer> coinInventoryObj = cashInventory.availableInventory();
		return coinInventoryObj;
	}
	
    public void exitVendingMachine(){
	System.out.println("Exiting Vending Machine !");
	System.exit(0);
    }
	
}