
public enum Coin  {
	ONE(1), TWO(2), FIVE(5), TEN(10), TWENTY(20), FIFTY(50), HUNDRED(100), FIVE_HUNDRED(500), TWO_THOUSAND(2000); 
	private int denomination; 
	private Coin(int denomination){
		this.denomination = denomination;
	}
	public int getDenomination(){
		return denomination;
	}
}

