/*
 * Factory pattern is used to encapsulate creation of Vending machine, right now its returning 
 * the default implementation but it could return a different type of Vending machine in future.
 */

public class VendingMachineFactory {

 public static VendingMachine createVendingMachine() {
	 
	 return new VendingMachineImpl();
 }
}
