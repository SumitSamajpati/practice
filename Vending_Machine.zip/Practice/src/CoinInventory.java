import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoinInventory<T> {
    private Map<T, Integer> inventory = new HashMap<T, Integer>();
   
    public int getQuantity(T item){
        Integer value = inventory.get(item);
        return value == null? 0 : value ;
    }
   
    public void add(T item, int quantity){
        int count=(inventory.get(item) == null ?0:inventory.get(item));
        inventory.put(item, count+quantity);
    }
    
    public void add(T item){
       // int count=(inventory.get(item) == null ?0:inventory.get(item));
        inventory.put(item,1);
    }
    
    public ArrayList<T> getAll() {
		return new ArrayList<T>(inventory.keySet());
	}
    
    public void deduct(T item, int quantity) {
        if (hasItem(item, quantity)) {
            int count = inventory.get(item);
            inventory.put(item, count - 1);
        }
    }
   
    public boolean hasItem(T item, int quantity) {
    	return getQuantity(item) >= quantity;
    }

    	
    public boolean hasItem(T item){
        return getQuantity(item) > 0;
    }
   
    public void clear(){
        inventory.clear();
    }

    public void put(T item, int quantity) {
        inventory.put(item, quantity);
    }
    
    public Map<T,Integer> availableInventory(){
		return inventory;
	}
}


