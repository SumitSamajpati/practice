import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class Machine{
		
public static void main(String args[])
{
    
    int inputChoice,amount,price, cash, quantity;
    String name, inputChar;
    new VendingMachineFactory();
	VendingMachine vm= VendingMachineFactory.createVendingMachine();
   // VendingMachineImpl vm= new VendingMachineImpl();
            
    Scanner input = new Scanner(System.in);
    System.out.println("Welcome to Vending Machine !");
    
      
    do
    {
    	System.out.println("If you are supplier, please press S, else C for consumer(Press 0 to exit)");
    	
    	while (!input.hasNext("[scSC]")) {
    		    System.out.println("That's not a valid input.Please try again ! Or enter 9 to go back to main menu !");
    		    inputChar=input.next();
    		    if(inputChar.equals("9"))
    		    	break;
    		    
    		}
    	inputChar=input.next();
        if(inputChar.equalsIgnoreCase("S")){
        	System.out.println("Enter");
        	System.out.println("1. Add item(s)/Restock");
        	System.out.println("2. Set Price(s)");
            System.out.println("3. Collect cash for item(s) purchased");
            System.out.println("4. Reduce Product");
            System.out.println("5. Add cash");
            System.out.println("6. Reset");
            System.out.println("7. Check Inventory");
            System.out.println("0. to exit the program");
            
            while (!input.hasNext("[01234567]")) {
    		    System.out.println("That's not a valid input!");
    		    input.next();
    		}
            inputChoice = input.nextInt();
            
            	/*if(inputChoice <0 || inputChoice > 7)
                {
                    System.out.println("That's not a valid input!");
                }*/
            	
            	if(inputChoice >= 0 || inputChoice <= 7)
                {
            		
                    switch(inputChoice)
                    {
                        case 0:
                        {
                         vm.exitVendingMachine();
                        }
                        break;
                        case 1:
                        {
                        	System.out.println("Quote name of the item:");
                        	name=input.next();
                        	//--------------------------------------------------//
                        	System.out.println("If you want to add/revise price of the item, please press 1, else press 2 ");
                        	while (!input.hasNext("[12]")) {
                    		    System.out.println("That's not a valid input. Please try again ! or enter E to go back to main menu");
                    		    inputChar=input.next();
                    		    if(inputChar.equalsIgnoreCase("E"))
                    		    	break; 
                    		}
                        	 if(inputChar.equalsIgnoreCase("E"))
                 		    	break; 
                        	inputChoice=input.nextInt();
                        	//----------------------------------------------------//
                        	if(inputChoice== 1){
                        	System.out.println("Quote price of the item:");
                        /*	do {
                        	       while (!input.hasNextInt()) {
                        	        System.out.println("That cannot be a price. Please try again ! Or enter E to go back to main menu !");
                        	        inputChar=input.next();
                        		    if(inputChar.equalsIgnoreCase("E"))
                        		    	break; 
                        	    }
                        	      
                        	       if(inputChar.equalsIgnoreCase("E"))
                       		    	break;
                        	      price = input.nextInt();
                        	} while (price <= 0);*/
                        	price = input.nextInt();
                        	//----------------------------------------------------//
                        	
                        	System.out.println("Quote quantity of the item:");
                        	/*do {
                     	       while (!input.hasNextInt()) {
                     	        System.out.println("That cannot be a quantity. Please try again ! or enter E to go the main menu ");
                     	        inputChar=input.next();
                     	        if(inputChar.equalsIgnoreCase("E"))
                     	        	break;
                     	    }
                     	      if(inputChar.equalsIgnoreCase("E"))
                   	        	break;
                     	      quantity = input.nextInt();
                        	} while (quantity <= 0);*/
                        	quantity=input.nextInt();
                        	
                        	vm.loadItems(name, price, quantity);
                        	System.out.println("Item added sucessfully !");
                        	}
                        	//---------------------------------------------------//
                        	else if(inputChoice == 2){
                        		System.out.println("Quote quantity of the item:");
                        		do {
                          	       while (!input.hasNextInt()) {
                          	        System.out.println("That cannot be a quantity. Please try again !");
                          	        input.next(); 
                          	    }
                          	      quantity = input.nextInt();
                          	} while (quantity <= 0);
                        		//quantity=input.nextInt();
                            	
                            	vm.loadItems(name, quantity);
                            	System.out.println("Item added sucessfully !");
                            	                           	
                        	}
                        	else{
                        		System.out.println("Invalid Input");
                        	}
                        	
                        }
                        break;
                        case 2:
                        {
                         System.out.println("Enter the item name for setting revised price:");
                         name= input.next();
                         while(!vm.getItemInventoryInstance().containsKey(name))
                         {
                        	 System.out.println("Item does not exist. Please try again ! Or press 9 to go back to main menu ! ");
                        	 name= input.next();
                        	 if(name.equals("9")){
                        		break;
                        	 }                       	 
                        	 
                         }	 
                         if(name.equals("9")){
                     		break;
                     	 }  
                         	// name=input.next();
                        	 System.out.println("Enter revised price:");
                      /*  	 do {
                      	       while (!input.hasNextInt()) {
                      	        System.out.println("That cannot be a price. Please try again !");
                      	        input.next(); 
                      	    }
                      	      price = input.nextInt();
                        	 } while (price <= 0);*/
                        	 
                        	 price = input.nextInt();
                        	 vm.updateItemPrice(name, price);
                                        
                        }
                        break;
                        case 3:
                        {
                         System.out.println("Collect total sale amount for the item(s) purchased by consumer(s):"+vm.getTotalSales());
                                        
                         vm.getSoldItemList();
                        }
                        break;
                        case 4:
                        {
                         System.out.println("Enter product name to reduce quantity");  
                         name= input.next();
                         while(!vm.getItemInventoryInstance().containsKey(name))
                         {
                        	 System.out.println("Item does not exist. Please try again ! ");
                        	 name= input.next();
                         }	  
                         
                         System.out.println("Enter product quantity to reduce"); 
                         do {
                    	       while (!input.hasNextInt()) {
                    	        System.out.println("That cannot be a quantity. Please try again !");
                    	        input.next(); 
                    	    }
                    	       inputChoice = input.nextInt();
                    	} while (inputChoice <= 0);
                        // inputChoice=input.nextInt();
                         
                         vm.reduceQuantity(name, inputChoice);
                         
                        }
                        break;
                        case 5:
                        {
                         System.out.println("Please enter the amount of cash in numeric to add to the Vending Machine:");
                        
                         do {
                  	       while (!input.hasNextInt()) {
                  	        System.out.println("That cannot be an acceptable amount. Please try again !");
                  	        input.next(); 
                  	       }
                  	       cash = input.nextInt();
                         } while (cash <= 0);
                       
                         vm.addCash(cash);
                         System.out.println("Cash successfully added to the inventory !");
                        }
                        break;
                        case 6:
                        {
                        	System.out.println("Enter 1 to reset both item and cash inventories, 2 to reset item inventory, 3 to reset cash inventory:");
                    		while (!input.hasNext("[123]")) {
                    		    System.out.println("That's not a valid input.Please try again ! ");
                    		    inputChar=input.next();
                    		    }
                    			inputChar=input.next();
                    		if(inputChar.equals("1"))	
                    			vm.resetInventory();
                        }
                        break;
                        case 7:
                        {
                         vm.printInventory();
                 		}
                        break;
                    }
                }
        }
        else if(inputChar.equals("c")){
        	
        System.out.println("Available products");
        vm.avilableItems();
        System.out.println("Enter 1 to purchase");                    
        System.out.println("Enter 0 to exit the program"); 
        
        while (!input.hasNext("[01]")) {
		    System.out.println("That's not a valid input. Please try again !");
		    input.next();
		}
        inputChoice = input.nextInt();
    
       /* if(inputChoice <0 || inputChoice > 1)
        {
            System.out.println("Invalid Input.  Please enter a valid selection!");
        }*/
        if(inputChoice >= 0 || inputChoice <= 1)
        {
            switch(inputChoice)
            {
                case 0:
                {
                 vm.exitVendingMachine();
                }
                break;
                case 1:
                {
                	System.out.println("Enter name of the product:");
                	name= input.next();
                    while(!vm.getItemInventoryInstance().containsKey(name))
                    {
                   	 System.out.println("Item does not exist. Please try again ! ");
                   	 name= input.next();
                    }	 
                	                	
                	System.out.println("Enter quantity of the product:");
                	do {
               	       while (!input.hasNextInt()) {
               	        System.out.println("That cannot be a quantity. Please try again !");
               	        input.next(); 
               	    }
               	      quantity = input.nextInt();
                	} while (quantity <= 0);
                	//quantity=input.nextInt();s
                	
                	ArrayList<Integer> arr= vm.getItemInventoryInstance().get(name);
                	if(quantity<=arr.get(0))
                	{
               	      int selectedItemPrice=vm.GetPrice(name, quantity);
               	      System.out.println("Price of "+quantity+" "+name+" : "+ selectedItemPrice);
               	      System.out.println("Please press 1 if you want to purchase, or 2 to cancel");
                	
                	while (!input.hasNext("[12]")) {
            		    System.out.println("That's not a valid input.Please try again !");
            		    input.next();
            		}
                	
                	if(input.nextInt()==1){
                		 
                		Item item=vm.getItem(name);
                    	
                    	//price = vm.selectItemAndGetPrice(item);
                    	System.out.println("Please pay :" + selectedItemPrice);
                    	do {
                   	       while (!input.hasNextInt()) {
                   	        System.out.println("That cannot be an amount. Please try again !");
                   	        input.next(); 
                   	    }
                   	    amount = input.nextInt();
                    	} while (amount <= 0);
                    	//amount=input.nextInt();
                    	vm.addCash(amount); 
                    	//vm.collectItemAndChange(); 
                    	Bucket<Item, Map<Coin, Integer>> bucket = vm.collectItemAndChange(item,quantity, amount);
                    	System.out.println("Please collect your item(s) and change");
                    	System.out.println("item  : " + bucket.getFirst().getName());
                    	System.out.println("quantity  :"+quantity);
                    	int change=amount-item.getPrice()*quantity;
                    	System.out.println("change  :" + change);
                    	
                    	for (Map.Entry<Coin, Integer> entry : bucket.getSecond().entrySet()) {
                    	    System.out.println(entry.getKey() + " \t\t " + entry.getValue());
                    	}
                    	
                		
                	}else if(inputChoice == 2){
                		System.out.println("Your order has been cancelled. You are entitled to take full refund of your paid amount.");
                		for (Map.Entry<Coin, Integer> entry : vm.refund().entrySet()) {
                    	    System.out.println(entry.getKey() + " \t\t " + entry.getValue());
                    	}
                	}
                	}
                    else{
                    	System.out.println("Not sufficient number of items in the inventory");
                   }
                	/*else
                		
                		System.out.println("Invalid Input. Please try again with vaild input.");*/
  		 
                }
                break;
            } 
      } 
} else {
	inputChoice = input.nextInt();
	if(inputChoice == 0)
		System.exit(0);
	else
	{
	System.out.println("Invalid Input. Please try again with vaild input.");
    
	}
 }
        
   }while (inputChoice != 0 || input.toString().equals("S") || input.toString().equals("C"));
    input.close();
}
}

